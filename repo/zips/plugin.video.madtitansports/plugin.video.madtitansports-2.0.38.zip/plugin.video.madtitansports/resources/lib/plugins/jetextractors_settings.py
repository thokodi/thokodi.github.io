import xbmcgui
import xbmcaddon
import xbmc
from ..plugin import Plugin
try:
    from jetextractors.tools import (
        is_debug_enabled, set_debug_logging,
        is_telegramxtream_enabled, set_telegramxtream_enabled,
        is_homeiptv_enabled, set_homeiptv_enabled,
        is_myiptv_enabled, set_myiptv_enabled,
        revalidate_telegramxtream, revalidate_homeiptv, revalidate_myiptv,
        get_extractor_names, is_extractor_enabled, set_extractor_disabled,
    )
except ImportError:
    is_debug_enabled = set_debug_logging = None
    is_telegramxtream_enabled = set_telegramxtream_enabled = None
    is_homeiptv_enabled = set_homeiptv_enabled = None
    is_myiptv_enabled = set_myiptv_enabled = None
    revalidate_telegramxtream = revalidate_homeiptv = None
    revalidate_myiptv = None
    get_extractor_names = is_extractor_enabled = set_extractor_disabled = None

addon_icon = xbmcaddon.Addon().getAddonInfo('icon')


class JetExtractorsSettings(Plugin):
    name = "jetextractors_settings"
    priority = 100

    def process_item(self, item):
        if self.name in item:
            link = item.get(self.name, "")
            if link.startswith("manage"):
                item["is_dir"] = True
                item["link"] = f"{self.name}/{link}"
                list_item = xbmcgui.ListItem(item.get("title", item.get("name", "")), offscreen=True)
                item["list_item"] = list_item
                return item

    def routes(self, plugin):
        @plugin.route(f"/{self.name}/manage")
        def manage():
            if is_debug_enabled is None:
                xbmcgui.Dialog().ok("JetExtractors Settings", "JetExtractors module not available or outdated.")
                return
            settings = [
                {"key": "debug_logging", "label": "Debug Logging", "getter": is_debug_enabled, "setter": set_debug_logging, "type": "toggle"},
                {"key": "telegramxtream_enabled", "label": "TelegramXtream Extractor", "getter": is_telegramxtream_enabled, "setter": set_telegramxtream_enabled, "type": "toggle"},
                {"key": "homeiptv_enabled", "label": "HomeIPTV Extractor", "getter": is_homeiptv_enabled, "setter": set_homeiptv_enabled, "type": "toggle"},
                {"key": "myiptv_enabled", "label": "MyIPTV Extractor", "getter": is_myiptv_enabled, "setter": set_myiptv_enabled, "type": "toggle"},
                {"key": "revalidate", "label": "Revalidate TelegramXtream", "action": revalidate_telegramxtream, "type": "action"},
                {"key": "revalidate_homeiptv", "label": "Revalidate HomeIPTV", "action": revalidate_homeiptv, "type": "action"},
                {"key": "revalidate_myiptv", "label": "Revalidate MyIPTV", "action": revalidate_myiptv, "type": "action"},
            ]

            if get_extractor_names is not None:
                try:
                    extractor_names = get_extractor_names()
                    for ext_name in extractor_names:
                        settings.append({
                            "key": f"extractor:{ext_name}",
                            "label": f"Scraper: {ext_name}",
                            "type": "scraper_toggle",
                            "name": ext_name,
                        })
                except Exception:
                    pass

            while True:
                items = []
                for setting in settings:
                    if setting.get("type") == "action":
                        label = f"[COLOR cyan]{setting['label']}[/COLOR]"
                    elif setting.get("type") == "scraper_toggle":
                        ext_name = setting.get("name", "")
                        try:
                            enabled = is_extractor_enabled(ext_name)
                        except Exception:
                            enabled = False
                        status = "[COLOR lime]ON[/COLOR]" if enabled else "[COLOR red]OFF[/COLOR]"
                        label = f"{status}  {setting['label']}"
                    else:
                        getter = setting.get("getter")
                        setter = setting.get("setter")
                        if getter is None or setter is None:
                            continue
                        try:
                            enabled = getter()
                        except Exception:
                            continue
                        status = "[COLOR lime]ON[/COLOR]" if enabled else "[COLOR red]OFF[/COLOR]"
                        label = f"{status}  {setting['label']}"
                    items.append(label)

                chosen = xbmcgui.Dialog().select(
                    "JetExtractors Settings (select to toggle)",
                    items,
                    preselect=-1,
                )

                if chosen == -1:
                    break

                selected = settings[chosen]
                if selected.get("type") == "action":
                    action_fn = selected.get("action")
                    if action_fn is None:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,Action not available,3000,%s)' % addon_icon
                        )
                        continue
                    try:
                        action_fn()
                    except Exception as e:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                        )
                    else:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,%s running...,3000,%s)' % (selected["label"], addon_icon)
                        )
                    continue
                elif selected.get("type") == "scraper_toggle":
                    ext_name = selected.get("name", "")
                    if not ext_name:
                        continue
                    try:
                        current = is_extractor_enabled(ext_name)
                    except Exception:
                        current = False
                    new_val = current
                    try:
                        set_extractor_disabled(ext_name, new_val)
                    except Exception as e:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,Failed to set: %s,3000,%s)' % (str(e), addon_icon)
                        )
                        continue
                    new_state = "disabled" if new_val else "enabled"
                    xbmc.executebuiltin(
                        'Notification(JetExtractors,%s %s,3000,%s)' % (selected["label"], new_state, addon_icon)
                    )
                else:
                    getter_fn = selected.get("getter")
                    setter_fn = selected.get("setter")
                    if getter_fn is None or setter_fn is None:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,Setting not available,3000,%s)' % addon_icon
                        )
                        continue
                    try:
                        current = getter_fn()
                    except Exception as e:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,Failed to read setting,3000,%s)' % addon_icon
                        )
                        continue
                    new_val = not bool(current)
                    try:
                        setter_fn(new_val)
                    except Exception as e:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,Failed to set setting,3000,%s)' % addon_icon
                        )
                        continue

                    new_state = "enabled" if new_val else "disabled"
                    xbmc.executebuiltin(
                        'Notification(JetExtractors,%s %s,3000,%s)' % (selected["label"], new_state, addon_icon)
                    )
                    if not current and selected["key"] == "telegramxtream_enabled" and revalidate_telegramxtream:
                        try:
                            revalidate_telegramxtream()
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Revalidating TelegramXtream...,5000,%s)' % addon_icon
                            )
                        except Exception as e:
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                            )
                    elif not current and selected["key"] == "homeiptv_enabled" and revalidate_homeiptv:
                        try:
                            revalidate_homeiptv()
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Revalidating HomeIPTV...,5000,%s)' % addon_icon
                            )
                        except Exception as e:
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                            )
                    elif not current and selected["key"] == "myiptv_enabled" and revalidate_myiptv:
                        try:
                            revalidate_myiptv()
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Revalidating MyIPTV...,5000,%s)' % addon_icon
                            )
                        except Exception as e:
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                            )
