import sys
import os
import xbmc
import xbmcaddon

ADDON_ID = "plugin.video.madtitansports"
ADDON = xbmcaddon.Addon(id=ADDON_ID)
addon_path = ADDON.getAddonInfo("path")

if addon_path not in sys.path:
    sys.path.insert(0, os.path.join(addon_path, "resources", "lib"))


_orig_addon = xbmcaddon.Addon

def _addon_with_context(id=None):
    if id is None:
        return _orig_addon(ADDON_ID)
    return _orig_addon(id)

xbmcaddon.Addon = _addon_with_context

from resources.lib.tool import log


def main():
    log(f"gui_launcher.py started with args: {sys.argv}")

    try:
        from resources.lib.gui_main import MadTitanGUI
        gui = MadTitanGUI('home.xml', addon_path, defaulttheme=False)
        gui.doModal()
        del gui
    except Exception as e:
        import xbmcgui
        xbmcgui.Dialog().ok('Mad Titan Sports', f'GUI failed to start:\n{e}')
        log(f"gui_launcher.py error: {e}")

    log("gui_launcher.py finished")


if __name__ == "__main__":
    main()
